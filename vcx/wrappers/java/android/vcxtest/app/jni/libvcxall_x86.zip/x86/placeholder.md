Put your lib.so files here
